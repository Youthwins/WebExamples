window.onload = init;

function init() {
    var button = document.getElementById("addButton"); //получаем доступ к кнокпе
    button.onclick = handleButtonClick; //как только кликнули по кнопке, вызываем функции handleButtonClick
    loadPlaylist();
}

function handleButtonClick(){
    var textInput = document.getElementById("songTextInput"); //получаем доступ к данным, которые пользователь ввел в поле
    var songName = textInput.value; //присваиваем переменной значение песни
    
    var li = document.createElement("li"); //создаем новые элемент "ли" в котором будет храниться название песни
    li.innerHTML = songName; //задаем содержимое ввиде названия песни
    var ul = document.getElementById("playlist"); ////получаем ссылку(доступ) на список "ул"
    
    ul.appendChild(li); //добавляем в родительский "ул" дочерний элемент "ли"
    save(songName);
    
    //здесь идет проверка: если значение песни не введно вызываем просьбу ввести песню, если введено, показываем строку "введите песню"
    if(songName == ""){
        alert("Введите песню!");
    }else{
        alert("Добавлена пенся: " + songName);
    }
}

